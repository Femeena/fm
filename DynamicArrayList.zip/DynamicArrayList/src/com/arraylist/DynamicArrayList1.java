package com.arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Employee{
	 public int id;
	 public String name;
	 public int age;
	 public int salary;
	// public static int count = 0;
	 public int sum=0;
	 
	 
	 public Employee(){}
	 
	 //Parameterized Constructor
	 public Employee(int id, String name,int age,int salary)
	 {
	 super();
	 this.id = id;
	 this.name = name;
	 this.age=age;
	 this.salary=salary;
	// count++;
	 }
	 
	 public int getId() {
	 return id;
	 }
	 
	 public String getName() {
	 return name;
	 }
	 
	 public int getAge() {
	 return age;
	 }
	 
	 public int getSalary() {
		 return salary;
	 }
	}
	 
	public class DynamicArrayList1 {
	public static void main(String[] args) throws Exception 
	{
	 List<Employee> list = new ArrayList<Employee>();
	 
	 list.add(new Employee(1, "Ravi",21,1000));
	 list.add(new Employee(2, "Raju",22,1250));
	 list.add(new Employee(3, "Rekha",23,1500));
	 list.add(new Employee(4, "Ram",24,1750));
	 list.add(new Employee(5, "Ravi",25,2000));
	 list.add(new Employee(6, "Raj",26,2250));
	 list.add(new Employee(7, "Rekha",27,2500));
	 list.add(new Employee(8, "Ram",28,2750));
	 list.add(new Employee(9, "Ravi",29,3000));
	 list.add(new Employee(10, "Raj",30,3250));
	 list.add(new Employee(11, "Rekha",31,3500));
	 list.add(new Employee(12, "Ram",32,3750));
	 list.add(new Employee(13, "Ravi",23,4000));
	 list.add(new Employee(14, "Rekha",31,3500));
	 list.add(new Employee(15, "Rekha",31,3500));
	 list.add(new Employee(16, "Rekha",31,3500));
	 list.add(new Employee(17, "Rekha",31,3500));
	 list.add(new Employee(18, "Rekha",31,3500));
	 list.add(new Employee(19, "Rekha",31,3500));
	 list.add(new Employee(20, "Rekha",31,3500));
	 list.add(new Employee(21, "Ravi",25,2000));
	 list.add(new Employee(22, "Rekha",31,3500));
	 list.add(new Employee(23, "Rekha",31,3500));
	 list.add(new Employee(24, "Rekha",31,3500));
	 list.add(new Employee(25, "Rekha",31,3500));
	 list.add(new Employee(26, "Rekha",31,3500));
	 list.add(new Employee(27, "Rekha",31,3500));
	 list.add(new Employee(28, "Rekha",31,3500));
	 list.add(new Employee(29, "Rekha",31,3500));
	 list.add(new Employee(30, "Rekha",31,3500));
	 list.add(new Employee(31, "Rekha",31,3500));
	 list.add(new Employee(32, "Rekha",31,3500));
	 list.add(new Employee(33, "Ravi",25,2000));
	 list.add(new Employee(34, "Rekha",31,3500));
	 list.add(new Employee(35,"Rekha",31,3500));
	 list.add(new Employee(36, "Rekha",31,3500));
	 list.add(new Employee(37, "Ravi",25,2000));
	 list.add(new Employee(38, "Rekha",31,3500));
	 list.add(new Employee(39, "Rekha",31,3500));
	 list.add(new Employee(40, "Rekha",31,3500));
	 list.add(new Employee(41, "Ravi",25,2000));
	 list.add(new Employee(42, "Raju",28,2500));
	 list.add(new Employee(43, "Rekha",31,3500));
	 list.add(new Employee(44, "Rekha",31,3500));
	 list.add(new Employee(45, "Ravi",25,2000));
	 list.add(new Employee(46, "Rekha",31,3500));
	 list.add(new Employee(47, "Rekha",31,3500));
	 list.add(new Employee(48, "Rekha",31,3500));
	 list.add(new Employee(49, "Ravi",25,2000));
	 list.add(new Employee(50, "Rekha",31,3500));
	 list.add(new Employee(51, "Rekha",31,3500));
	 list.add(new Employee(52, "Rekha",31,3500));
	 list.add(new Employee(53, "Ravi",25,2000));
	 list.add(new Employee(54, "Rekha",31,3500));
	 list.add(new Employee(55, "Rekha",31,3500));
	 list.add(new Employee(56, "Rekha",31,3500));
	 list.add(new Employee(57, "Ravi",25,2000));
	 list.add(new Employee(58, "Rekha",31,3500));
	 list.add(new Employee(59, "Rekha",31,3500));
	 list.add(new Employee(60, "Rekha",31,3500));
	 list.add(new Employee(61, "Ravi",25,2000));
	 list.add(new Employee(62, "Rekha",31,3500));
	 list.add(new Employee(63, "Rekha",31,3500));
	 list.add(new Employee(64, "Rekha",31,3500));
	 list.add(new Employee(65, "Ravi",25,2000));
	 list.add(new Employee(66, "Rekha",31,3500));
	 list.add(new Employee(67, "Rekha",31,3500));
	 list.add(new Employee(68, "Rekha",31,3500));
	 list.add(new Employee(69, "Ravi",25,2000));
	 list.add(new Employee(70, "Rekha",31,3500));
	 list.add(new Employee(71, "Rekha",31,3500));
	 list.add(new Employee(72, "Rekha",31,3500));
	 list.add(new Employee(73, "Ravi",25,2000));
	 list.add(new Employee(74, "Raj",26,3000));
	 list.add(new Employee(75, "Rekha",31,3500));
	 list.add(new Employee(76, "Rekha",31,3500));
	 list.add(new Employee(77, "Ravi",25,2000));
	 list.add(new Employee(78, "Rekha",31,3500));
	 list.add(new Employee(79, "Rekha",31,3500));
	 list.add(new Employee(80, "Rekha",31,3500));
	 list.add(new Employee(81, "Ravi",25,2000));
	 list.add(new Employee(82, "Rekha",31,3500));
	 list.add(new Employee(83, "Rekha",31,3500));
	 list.add(new Employee(84, "Rekha",31,3500));
	 list.add(new Employee(85, "Ravi",25,2000));
	 list.add(new Employee(86, "Rekha",31,3500));
	 list.add(new Employee(87, "Rekha",31,3500));
	 list.add(new Employee(88, "Rekha",31,3500));
	 list.add(new Employee(89, "Ravi",25,2000));
	 list.add(new Employee(90,"Ravi",25,2000));
	 list.add(new Employee(91, "Ravi",25,2000));
	 list.add(new Employee(92, "Ravi",25,2000));
	 list.add(new Employee(93, "Ravi",25,2000));
	 list.add(new Employee(94, "Raj",26,3000));
	 list.add(new Employee(95, "Ravi",25,2000));
	 list.add(new Employee(96, "Ravi",25,2000));
	 list.add(new Employee(97, "Ravi",25,2000));
	 list.add(new Employee(98,"Ravi",25,2000));
	 list.add(new Employee(99, "Ravi",25,2000));
	 list.add(new Employee(100, "Ravi",25,2000));
	 
	 
	 for (Employee s : list) //Iterates as long as there are elements in the list. An object s is created of type Employee class.
	 {
		 int salari=s.getSalary()+s.getAge();
		 
		 if(salari>3000) {

			 
			System.out.println(salari+" "+s.getName()+" "+s.getAge());
			 
			  }
	 }
	 int count = 0;
	 int sum=0;
	 int avg=0;
	 for(Employee s:list) {
		 int sal=s.getSalary()+s.getAge();
		 
		 while(sal>3000) {
	int  r=s.getAge();

	System.out.println("age"+r);
	sum=sum+r;
	count++;
	
	break;
	
	}
	 
	 }
	 System.out.println(count);
	 avg=sum/count;
	 System.out.println(avg);
	 }
	}